# Grafana Candlestick Panel

### Screenshots

#### Changelog

##### v0.0.1

- First working version
